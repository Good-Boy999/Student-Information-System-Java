



public class GraduateStudent extends Student {
    private String thesisTitle;

    public GraduateStudent(String name, int age, double marks, String thesisTitle) {
        super(name, age, marks);
        this.thesisTitle = thesisTitle;
    }

    @Override
    public void display() {
        super.display();
        System.out.println("Thesis : " + thesisTitle);
        System.out.println("-----------------------------");
    }
}
/* 
public class GraduateStudent extends Student {
    private String thesisTitle;

    public GraduateStudent(String name, int age, double marks, String thesisTitle) {
        super(name, age, marks);
        this.thesisTitle = thesisTitle;
    }

    @Override
    public void display() {
        super.display();
        System.out.println("Thesis : " + thesisTitle);
        System.out.println("-----------------------------");
    }
}
*/
