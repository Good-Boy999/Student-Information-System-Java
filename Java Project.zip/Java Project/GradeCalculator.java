



public interface GradeCalculator {
    String getGrade(double marks);  // Method to calculate grade based on marks
}
/* 
public interface GradeCalculator {
    String getGrade(double marks);  // Contract method
}
*/
