



public class Student extends Person implements GradeCalculator {
    private static int count = 0;  // Static variable to track number of students
    private int id;
    protected double marks;

    // Constructor with all parameters
    public Student(String name, int age, double marks) {
        super(name, age);
        this.marks = marks;
        this.id = ++count;  // Assign unique ID
    }

    // Overloaded constructor (default age)
    public Student(String name, double marks) {
        this(name, 18, marks);  // Calls main constructor with default age 18
    }

    public int getId() {
        return id;
    }

    @Override
    public String getGrade(double marks) {
        if (marks >= 90) return "A";
        else if (marks >= 80) return "B";
        else if (marks >= 70) return "C";
        else if (marks >= 60) return "D";
        else return "F";
    }

    // Display method
    public void display() {
        System.out.println("ID     : " + id);
        System.out.println("Name   : " + name);
        System.out.println("Age    : " + age);
        System.out.println("Marks  : " + marks);
        System.out.println("Grade  : " + getGrade(marks));
        System.out.println("-----------------------------");
    }

    // Overloaded display method
    public void display(String message) {
        System.out.println(message);
        display();  // Calls original display method
    }

    // Static method to get total student count
    public static int getStudentCount() {
        return count;
    }

    // Static method to decrease student count
public static void decreaseStudentCount() {
    //count--;
    if (count > 0) count--;
}

}
/* 
public class Student extends Person implements GradeCalculator {
    private static int count = 0;  // Static variable
    private int id;
    protected double marks;

    public Student(String name, int age, double marks) {
        super(name, age);
        this.marks = marks;
        this.id = ++count;  // Unique ID assigned
    }

    // Overloaded constructor (constructor overloading)
    public Student(String name, double marks) {
        this(name, 18, marks);  // Default age 18
    }

    public int getId() {
        return id;
    }

    @Override
    public String getGrade(double marks) {
        if (marks >= 90) return "A";
        else if (marks >= 80) return "B";
        else if (marks >= 70) return "C";
        else if (marks >= 60) return "D";
        else return "F";
    }

    public void display() {
        System.out.println("ID     : " + id);
        System.out.println("Name   : " + name);
        System.out.println("Age    : " + age);
        System.out.println("Marks  : " + marks);
        System.out.println("Grade  : " + getGrade(marks));
        System.out.println("-----------------------------");
    }
}
*/