



import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Student> studentList = new ArrayList<>();

        // Preloaded sample students
        studentList.add(new Student("Alice", 20, 85.5));
        studentList.add(new GraduateStudent("Bob", 24, 92.0, "Machine Learning"));
        studentList.add(new Student("Charlie", 19, 73.0));

        int choice;
        do {
            // Display the menu
            System.out.println("\n===== Student Information System =====");
            System.out.println("1. View All Students");
            System.out.println("2. Add New Student");
            System.out.println("3. Add Graduate Student");
            System.out.println("4. Delete Student by ID");
            System.out.println("5. View Total Students");
            System.out.println("6. Search Student by ID"); // New feature
            System.out.println("7. Exit");
            System.out.print("Choose option: ");
            choice = sc.nextInt();
            sc.nextLine(); // Clear input buffer

            switch (choice) {
                case 1: // View all students
                    if (studentList.isEmpty()) {
                        System.out.println("No students found.");
                    } else {
                        for (Student s : studentList) {
                            s.display("Student Record:");
                        }
                    }
                    break;

                case 2: // Add new student
                    System.out.print("Enter Name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter Age: ");
                    int age = sc.nextInt();
                    System.out.print("Enter Marks: ");
                    double marks = sc.nextDouble();
                    studentList.add(new Student(name, age, marks));
                    System.out.println("Student added successfully!");
                    break;

                case 3: // Add graduate student
                    System.out.print("Enter Name: ");
                    String gName = sc.nextLine();
                    System.out.print("Enter Age: ");
                    int gAge = sc.nextInt();
                    System.out.print("Enter Marks: ");
                    double gMarks = sc.nextDouble();
                    sc.nextLine();
                    System.out.print("Enter Thesis Title: ");
                    String thesis = sc.nextLine();
                    studentList.add(new GraduateStudent(gName, gAge, gMarks, thesis));
                    System.out.println("Graduate student added!");
                    break;

                case 4: // Delete student by ID
                    System.out.print("Enter Student ID to delete: ");
                    int idToDelete = sc.nextInt();
                    boolean deleted = false;
                    for (int i = 0; i < studentList.size(); i++) {
                        if (studentList.get(i).getId() == idToDelete) {
                            studentList.remove(i);
                            Student.decreaseStudentCount();
                            System.out.println("Student deleted successfully.");
                            deleted = true;
                            break;
                        }
                    }
                    if (!deleted) {
                        System.out.println("Student ID not found.");
                    }
                    break;

                case 5: // View total students
                    System.out.println("Total students: " + Student.getStudentCount());
                    break;

                case 6: // Search student by ID (New Feature)
                    System.out.print("Enter Student ID to search: ");
                    int idToSearch = sc.nextInt();
                    boolean found = false;
                    for (Student s : studentList) {
                        if (s.getId() == idToSearch) {
                            s.display("Found Student Record:");
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        System.out.println("Student ID not found.");
                    }
                    break;

                case 7: // Exit
                    System.out.println("Exiting... Thank you!");
                    break;

                default:
                    System.out.println("Invalid option. Try again.");
            }
        } while (choice != 7);

        sc.close();
    }
}

/* 
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Student> studentList = new ArrayList<>();

        // Preloaded student records
        studentList.add(new Student("Alice", 20, 85.5));
        studentList.add(new GraduateStudent("Bob", 24, 92.0, "Machine Learning"));
        studentList.add(new Student("Charlie", 19, 73.0));

        int choice;
        do {
            System.out.println("\n===== Student Information System =====");
            System.out.println("1. View All Students");
            System.out.println("2. Add New Student");
            System.out.println("3. Add Graduate Student");
            System.out.println("4. Delete Student by ID");
            System.out.println("5. View Total Students");
            System.out.println("6. Exit");
            System.out.print("Choose option: ");
            choice = sc.nextInt();
            sc.nextLine(); // Clear buffer

            switch (choice) {
                case 1:
                    if (studentList.isEmpty()) {
                        System.out.println("⚠ No students found.");
                    } else {
                        for (Student s : studentList) {
                            s.display("Student Record:");  // Uses overloaded display
                        }
                    }
                    break;

                case 2:
                    System.out.print("Enter Name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter Age: ");
                    int age = sc.nextInt();
                    System.out.print("Enter Marks: ");
                    double marks = sc.nextDouble();
                    studentList.add(new Student(name, age, marks));
                    System.out.println("Student added successfully!");
                    break;

                case 3:
                    System.out.print("Enter Name: ");
                    String gName = sc.nextLine();
                    System.out.print("Enter Age: ");
                    int gAge = sc.nextInt();
                    System.out.print("Enter Marks: ");
                    double gMarks = sc.nextDouble();
                    sc.nextLine();  // Clear buffer
                    System.out.print("Enter Thesis Title: ");
                    String thesis = sc.nextLine();
                    studentList.add(new GraduateStudent(gName, gAge, gMarks, thesis));
                    System.out.println("Graduate student added!");
                    break;

                case 4:
                    System.out.print("Enter Student ID to delete: ");
                    int idToDelete = sc.nextInt();
                    boolean found = false;
                    for (int i = 0; i < studentList.size(); i++) {
                        if (studentList.get(i).getId() == idToDelete) {
                            studentList.remove(i);
                            System.out.println("🗑 Student deleted successfully.");
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        System.out.println("Student ID not found.");
                    }
                    break;

                case 5:
                    System.out.println("Total students: " + Student.getStudentCount());
                    break;

                case 6:
                    System.out.println("Exiting... Thank you!");
                    break;

                default:
                    System.out.println("Invalid option. Try again.");
            }

        } while (choice != 6);

        sc.close();
    }
}
*/
/* 
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Student> studentList = new ArrayList<>();

        // 🔹 Preloaded student records
        studentList.add(new Student("Alice", 20, 85.5));
        studentList.add(new GraduateStudent("Bob", 24, 92.0, "Machine Learning"));
        studentList.add(new Student("Charlie", 19, 73.0));

        int choice;
        do {
            System.out.println("\n===== Student Information System =====");
            System.out.println("1. View All Students");
            System.out.println("2. Add New Student");
            System.out.println("3. Add Graduate Student");
            System.out.println("4. Delete Student by ID");
            System.out.println("5. Exit");
            System.out.print("Choose option: ");
            choice = sc.nextInt();
            sc.nextLine(); // Clear buffer

            switch (choice) {
                case 1:
                    if (studentList.isEmpty()) {
                        System.out.println("⚠ No students found.");
                    } else {
                        for (Student s : studentList) {
                            s.display();
                        }
                    }
                    break;

                case 2:
                    System.out.print("Enter Name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter Age: ");
                    int age = sc.nextInt();
                    System.out.print("Enter Marks: ");
                    double marks = sc.nextDouble();
                    studentList.add(new Student(name, age, marks));
                    System.out.println("Student added successfully!");
                    break;

                case 3:
                    System.out.print("Enter Name: ");
                    String gName = sc.nextLine();
                    System.out.print("Enter Age: ");
                    int gAge = sc.nextInt();
                    System.out.print("Enter Marks: ");
                    double gMarks = sc.nextDouble();
                    sc.nextLine();  // Clear buffer
                    System.out.print("Enter Thesis Title: ");
                    String thesis = sc.nextLine();
                    studentList.add(new GraduateStudent(gName, gAge, gMarks, thesis));
                    System.out.println("Graduate student added!");
                    break;

                case 4:
                    System.out.print("Enter Student ID to delete: ");
                    int idToDelete = sc.nextInt();
                    boolean found = false;
                    for (int i = 0; i < studentList.size(); i++) {
                        if (studentList.get(i).getId() == idToDelete) {
                            studentList.remove(i);
                            found = true;
                            System.out.println("🗑 Student deleted successfully.");
                            break;
                        }
                    }
                    if (!found) {
                        System.out.println("Student ID not found.");
                    }
                    break;

                case 5:
                    System.out.println("Exiting... Thank you!");
                    break;

                default:
                    System.out.println("Invalid option. Try again.");
            }

        } while (choice != 5);

        sc.close();
    }
}
*/
